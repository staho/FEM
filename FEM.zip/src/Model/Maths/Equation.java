package Model.Maths;

import Jama.Matrix;

public class Equation {
    public static double function(double x, double y){
        return 2*x*x*y*y + 6*x + 5; //funkcja od p. Kustry
    }
}
