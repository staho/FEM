package Model.Maths;

public class Integral {
}
